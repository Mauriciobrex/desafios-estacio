#ifndef FUNCOES_H
#define FUNCOES_H

typedef struct Territorio {
    int id;
    char nome[50];
    int tropas;
    struct Territorio *prox;
} Territorio;

typedef struct ListaTerritorios {
    Territorio *inicio;
} ListaTerritorios;

ListaTerritorios* criarLista();
Territorio* criarTerritorio(int id, const char *nome, int tropas);
void adicionar(ListaTerritorios *lista, int id, const char *nome, int tropas);
void listar(ListaTerritorios *lista);
Territorio* buscar(ListaTerritorios *lista, int id);
void remover(ListaTerritorios *lista, int id);
void atacar(ListaTerritorios *lista, int id_origem, int id_alvo);
void moverTropas(ListaTerritorios *lista, int id_origem, int id_destino, int qtd);
void menu();

#endif
