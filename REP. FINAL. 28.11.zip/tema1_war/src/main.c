#include <stdio.h>
#include "funcoes.h"

int main() {
    ListaTerritorios *lista = criarLista();

    adicionar(lista, 1, "Brasil", 10);
    adicionar(lista, 2, "Argentina", 8);
    adicionar(lista, 3, "Chile", 12);

    int op;
    do {
        menu();
        scanf("%d", &op);
        switch(op) {
            case 1: listar(lista); break;
            case 2: {
                int id, tropas; char nome[50];
                printf("ID: "); scanf("%d", &id);
                printf("Nome: "); scanf("%s", nome);
                printf("Tropas: "); scanf("%d", &tropas);
                adicionar(lista, id, nome, tropas);
                break;
            }
            case 3: { int id; printf("ID para remover: "); scanf("%d", &id); remover(lista, id); break; }
            case 4: { int id1,id2; printf("ID origem: "); scanf("%d", &id1); printf("ID alvo: "); scanf("%d", &id2); atacar(lista, id1, id2); break; }
            case 5: { int id1,id2,qtd; printf("ID origem: "); scanf("%d", &id1); printf("ID destino: "); scanf("%d", &id2); printf("Quantidade: "); scanf("%d", &qtd); moverTropas(lista, id1, id2, qtd); break; }
        }
    } while(op != 0);
    return 0;
}
