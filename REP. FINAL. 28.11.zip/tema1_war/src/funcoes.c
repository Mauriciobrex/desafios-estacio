#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

ListaTerritorios* criarLista() {
    ListaTerritorios *l = (ListaTerritorios*) malloc(sizeof(ListaTerritorios));
    l->inicio = NULL;
    return l;
}

Territorio* criarTerritorio(int id, const char *nome, int tropas) {
    Territorio *t = (Territorio*) malloc(sizeof(Territorio));
    t->id = id;
    strncpy(t->nome, nome, 49);
    t->nome[49] = '\0';
    t->tropas = tropas;
    t->prox = NULL;
    return t;
}

void adicionar(ListaTerritorios *lista, int id, const char *nome, int tropas) {
    Territorio *t = criarTerritorio(id, nome, tropas);
    t->prox = lista->inicio;
    lista->inicio = t;
}

void listar(ListaTerritorios *lista) {
    Territorio *aux = lista->inicio;
    printf("\n=== TERRITÓRIOS ===\n");
    while(aux) {
        printf("ID: %d | Nome: %s | Tropas: %d\n", aux->id, aux->nome, aux->tropas);
        aux = aux->prox;
    }
}

Territorio* buscar(ListaTerritorios *lista, int id) {
    Territorio *aux = lista->inicio;
    while(aux) {
        if(aux->id == id) return aux;
        aux = aux->prox;
    }
    return NULL;
}

void remover(ListaTerritorios *lista, int id) {
    Territorio *aux = lista->inicio;
    Territorio *ant = NULL;
    while(aux) {
        if(aux->id == id) {
            if(ant == NULL) lista->inicio = aux->prox;
            else ant->prox = aux->prox;
            free(aux);
            printf("Território removido!\n");
            return;
        }
        ant = aux;
        aux = aux->prox;
    }
    printf("ID não encontrado!\n");
}

void atacar(ListaTerritorios *lista, int id_origem, int id_alvo) {
    Territorio *origem = buscar(lista, id_origem);
    Territorio *alvo = buscar(lista, id_alvo);
    if(!origem || !alvo) { printf("Um dos territórios não existe!\n"); return; }
    if(origem->tropas <= 1) { printf("O território de origem não tem tropas suficientes para atacar!\n"); return; }
    if(origem->tropas > alvo->tropas) {
        printf("%s conquistou %s!\n", origem->nome, alvo->nome);
        origem->tropas -= 1;
        alvo->tropas = origem->tropas / 2;
    } else {
        printf("%s perdeu o ataque para %s!\n", origem->nome, alvo->nome);
        origem->tropas -= 2;
        if(origem->tropas < 0) origem->tropas = 0;
    }
}

void moverTropas(ListaTerritorios *lista, int id_origem, int id_destino, int qtd) {
    Territorio *origem = buscar(lista, id_origem);
    Territorio *dest = buscar(lista, id_destino);
    if(!origem || !dest) { printf("Território inválido!\n"); return; }
    if(origem->tropas <= qtd) { printf("Tropas insuficientes para mover!\n"); return; }
    origem->tropas -= qtd;
    dest->tropas += qtd;
    printf("%d tropas movidas de %s para %s\n", qtd, origem->nome, dest->nome);
}

void menu() {
    printf("\n========= MENU WAR =========\n");
    printf("1. Listar territórios\n");
    printf("2. Adicionar território\n");
    printf("3. Remover território\n");
    printf("4. Atacar território\n");
    printf("5. Mover tropas\n");
    printf("0. Sair\n");
    printf("Escolha: ");
}
