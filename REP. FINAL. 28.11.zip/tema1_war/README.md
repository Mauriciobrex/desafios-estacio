# Tema 1 — Desafio War Estruturado (Tema 1)

Resumo:
Implementar a base lógica do jogo WAR em linguagem C, usando structs, alocação dinâmica, ponteiros e modularização. Funcionalidades: cadastro de territórios, sistema de ataque simples, movimentação de tropas, buscar/remover territórios.

Como compilar:
gcc main.c funcoes.c -o war
./war
