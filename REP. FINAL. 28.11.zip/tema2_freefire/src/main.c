#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 50

typedef struct { char nome[50]; char tipo[30]; int prioridade; } Item;

typedef struct { Item itens[MAX]; int tamanho; } ListaSequencial;

typedef struct No { Item dado; struct No* prox; } No;

void inicializarLista(ListaSequencial *l) { l->tamanho = 0; }
void inserirItemSeq(ListaSequencial *l, Item it) { if (l->tamanho>=MAX) { printf("Inventário cheio!\n"); return; } l->itens[l->tamanho++]=it; }
void removerItemSeq(ListaSequencial *l, char nome[]) { for (int i=0;i<l->tamanho;i++){ if (strcmp(l->itens[i].nome,nome)==0){ for (int j=i;j<l->tamanho-1;j++) l->itens[j]=l->itens[j+1]; l->tamanho--; printf("Item removido!\n"); return; } } printf("Item não encontrado!\n"); }
void listarSeq(ListaSequencial l){ if (l.tamanho==0){ printf("Inventário vazio!\n"); return;} for (int i=0;i<l.tamanho;i++) printf("%d - %s (%s) Prioridade: %d\n", i+1, l.itens[i].nome, l.itens[i].tipo, l.itens[i].prioridade); }
void selectionSort(ListaSequencial *l){ for (int i=0;i<l->tamanho-1;i++){ int min=i; for (int j=i+1;j<l->tamanho;j++) if (strcmp(l->itens[j].nome,l->itens[min].nome)<0) min=j; if (min!=i){ Item tmp=l->itens[i]; l->itens[i]=l->itens[min]; l->itens[min]=tmp;} } }
int buscaBinaria(ListaSequencial *l, char nome[]){ int inicio=0,fim=l->tamanho-1; while(inicio<=fim){ int meio=(inicio+fim)/2; int cmp=strcmp(nome,l->itens[meio].nome); if (cmp==0) return meio; else if (cmp<0) fim=meio-1; else inicio=meio+1; } return -1; }
No* inserirEnc(No* lista, Item it){ No* novo=(No*)malloc(sizeof(No)); novo->dado=it; novo->prox=lista; return novo; }
void listarEnc(No* lista){ No* atual=lista; while(atual){ printf("%s (%s) P:%d\n", atual->dado.nome, atual->dado.tipo, atual->dado.prioridade); atual=atual->prox; } }

int main(){ ListaSequencial inventario; inicializarLista(&inventario); No* listaDinamica=NULL; int opc; Item it; char nomeBusca[50];
 do{ printf("\n===== MENU FREE FIRE =====\n1-Adicionar 2-Remover 3-Listar 4-Ordenar 5-Buscar 6-InserirEnc 7-ListarEnc 0-Sair\nEscolha: "); scanf("%d", &opc);
 switch(opc){ case 1: printf("Nome: "); scanf("%s", it.nome); printf("Tipo: "); scanf("%s", it.tipo); printf("Prioridade: "); scanf("%d", &it.prioridade); inserirItemSeq(&inventario,it); break; case 2: printf("Nome para remover: "); scanf("%s", nomeBusca); removerItemSeq(&inventario,nomeBusca); break; case 3: listarSeq(inventario); break; case 4: selectionSort(&inventario); printf("Ordenado!\n"); break; case 5: printf("Nome pra buscar: "); scanf("%s", nomeBusca); { int pos=buscaBinaria(&inventario,nomeBusca); if (pos>=0) printf("Encontrado na pos %d\n", pos+1); else printf("Nao encontrado\n"); } break; case 6: printf("Nome: "); scanf("%s", it.nome); printf("Tipo: "); scanf("%s", it.tipo); printf("Prioridade: "); scanf("%d", &it.prioridade); listaDinamica=inserirEnc(listaDinamica,it); break; case 7: listarEnc(listaDinamica); break; }
 } while(opc!=0);
 return 0; }
