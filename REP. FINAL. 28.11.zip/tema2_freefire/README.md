# Tema 2 — Desafio Free Fire (Tema 2)

Resumo:
Implementar em C estruturas de dados (lista sequencial e lista encadeada), operações de inserção, remoção, percorrimento, busca sequencial e binária, e técnicas de ordenação (Selection Sort).

Como compilar:
gcc main.c -o freefire
./freefire
