# Tema 4 — Desafio Detective Quest (Tema 4)

Resumo:
Implementar em C estruturas de dados (árvore binária, árvore de busca e tabela hash) para organizar mapa, pistas e relacionar pistas a suspeitos.

Como compilar:
gcc main.c -o detective
./detective
