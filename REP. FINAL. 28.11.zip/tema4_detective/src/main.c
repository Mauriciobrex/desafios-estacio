#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct NoA { char local[50]; struct NoA *esq, *dir; } NoA;
typedef struct NoBST { char chave[100]; struct NoBST *esq, *dir; } NoBST;

NoA* novoNoA(const char *local) { NoA* n=(NoA*)malloc(sizeof(NoA)); strcpy(n->local, local); n->esq=n->dir=NULL; return n; }
NoBST* novoNoBST(const char *chave) { NoBST* n=(NoBST*)malloc(sizeof(NoBST)); strcpy(n->chave, chave); n->esq=n->dir=NULL; return n; }
NoBST* inserirBST(NoBST* raiz, const char *chave) { if (!raiz) return novoNoBST(chave); if (strcmp(chave, raiz->chave)<0) raiz->esq=inserirBST(raiz->esq,chave); else raiz->dir=inserirBST(raiz->dir,chave); return raiz; }
void imprimirBST(NoBST* raiz) { if (!raiz) return; imprimirBST(raiz->esq); printf("%s\n", raiz->chave); imprimirBST(raiz->dir); }

int main(){ NoA *mapa = novoNoA("Entrada"); mapa->esq=novoNoA("Sala"); mapa->dir=novoNoA("Biblioteca"); NoBST *pistas=NULL; int opc; char buffer[128]; do{ printf("\n===== DETECTIVE QUEST (simples) =====\n1-Add pista 2-Listar pistas 0-Sair\nEscolha: "); scanf("%d", &opc); getchar(); if (opc==1){ printf("Descricao da pista: "); fgets(buffer,128,stdin); buffer[strcspn(buffer,"\n")]=0; pistas=inserirBST(pistas,buffer);} else if (opc==2){ printf("\nPistas (ordenadas):\n"); imprimirBST(pistas);} } while(opc!=0); return 0; }
