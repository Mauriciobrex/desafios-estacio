#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PECAS 50

typedef struct { char nome[20]; int linhas; int colunas; } Peca;

typedef struct { Peca pecas[MAX_PECAS]; int topo; } Pilha;
typedef struct { Peca dados[MAX_PECAS]; int inicio, fim, qtd; } Fila;

void inicializarPilha(Pilha *p) { p->topo = -1; }
int vaziaPilha(Pilha *p) { return p->topo == -1; }
int cheiaPilha(Pilha *p) { return p->topo == MAX_PECAS-1; }
void push(Pilha *p, Peca x) { if (!cheiaPilha(p)) p->pecas[++p->topo] = x; else printf("Pilha cheia!\n"); }
Peca pop(Pilha *p) { Peca vazio={"",0,0}; if (vaziaPilha(p)) { printf("Pilha vazia!\n"); return vazio; } return p->pecas[p->topo--]; }

void inicializarFila(Fila *f) { f->inicio=0; f->fim=-1; f->qtd=0; }
int vaziaFila(Fila *f) { return f->qtd==0; }
int cheiaFila(Fila *f) { return f->qtd==MAX_PECAS; }
void enfileirar(Fila *f, Peca x) { if (cheiaFila(f)) { printf("Fila cheia!\n"); return; } f->fim=(f->fim+1)%MAX_PECAS; f->dados[f->fim]=x; f->qtd++; }
Peca desenfileirar(Fila *f) { Peca vazio={"",0,0}; if (vaziaFila(f)) { printf("Fila vazia!\n"); return vazio; } Peca r=f->dados[f->inicio]; f->inicio=(f->inicio+1)%MAX_PECAS; f->qtd--; return r; }

int main() {
    Pilha reserva; Fila fila; inicializarPilha(&reserva); inicializarFila(&fila);
    int opc; Peca p;
    do {
        printf("\n===== TETRIS STACK =====\n1-Push 2-Pop 3-Enfileirar 4-Desenfileirar 5-Trocar 6-Listar 0-Sair\nEscolha: "); scanf("%d", &opc);
        switch(opc) {
            case 1: printf("Nome: "); scanf("%s", p.nome); printf("Linhas: "); scanf("%d", &p.linhas); printf("Colunas: "); scanf("%d", &p.colunas); push(&reserva,p); break;
            case 2: { Peca r=pop(&reserva); if (strlen(r.nome)) printf("Removida: %s\n", r.nome); } break;
            case 3: printf("Nome: "); scanf("%s", p.nome); printf("Linhas: "); scanf("%d", &p.linhas); printf("Colunas: "); scanf("%d", &p.colunas); enfileirar(&fila,p); break;
            case 4: { Peca r=desenfileirar(&fila); if (strlen(r.nome)) printf("Desenfileirada: %s\n", r.nome); } break;
            case 5: { Peca r=desenfileirar(&fila); if (strlen(r.nome)) { push(&reserva,r); printf("Trocou peça da fila para pilha: %s\n", r.nome); } else printf("Nenhuma peça para trocar\n"); } break;
            case 6: {
                printf("\nPilha (topo->baixo):\n"); for (int i=reserva.topo;i>=0;i--) printf("%s (%dx%d)\n", reserva.pecas[i].nome, reserva.pecas[i].linhas, reserva.pecas[i].colunas);
                printf("\nFila (da frente->fim):\n"); int idx=fila.inicio; for (int i=0;i<fila.qtd;i++){ Peca q=fila.dados[idx]; printf("%s (%dx%d)\n", q.nome, q.linhas, q.colunas); idx=(idx+1)%MAX_PECAS; }
            } break;
        }
    } while(opc!=0);
    return 0;
}
