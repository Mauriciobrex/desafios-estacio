# Tema 3 — Desafio Tetris Stack (Tema 3)

Resumo:
Implementar fila circular e pilha em C para controlar peças do jogo Tetris Stack, com operações push/pop e enfileirar/desenfileirar, além de permitir troca entre estruturas.

Como compilar:
gcc main.c -o tetris
./tetris
